<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $name        = htmlspecialchars(trim($_POST['name']));
    $phone       = htmlspecialchars(trim($_POST['phone']));
    $email       = htmlspecialchars(trim($_POST['email']));
    $city       = htmlspecialchars(trim($_POST['city']));
    $destination = htmlspecialchars(trim($_POST['destination']));

    $to = " sales@indianmountainrovers.com"; // CHANGE IF NEEDED
    $subject = "New Travel Booking Enquiry | Spiti Tour Packages";

    $message = "
New Booking Request
-------------------
Name: $name
Phone: $phone
Email: $email
City: $city
Destination: $destination
";

    $headers  = "From: $name <$email>\r\n";
    $headers .= "Reply-To: $email\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";

    if (mail($to, $subject, $message, $headers)) {
        // ✅ Redirect to Thank You page
        header("Location: thanks.html");
        exit;
    } else {
        echo "Something went wrong. Please try again.";
    }
}
?>
